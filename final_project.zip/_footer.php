</div>
<footer>	
	<ul>
		<li>
			<a href = "https://github.com/SamMorey"><img src="imgs/fly_sam.jpg" alt="Sam's GitHub" class= "team"></a>
		</li>
		<li>
			<a href = "https://github.com/kollch"><img src="imgs/kollch.png" alt="Charles's GitHub" class="team"></a>
		</li>
		<li>
			<a href = "https://github.com/atkinson137"><img src="imgs/atkinsor.png" alt="Ryan's GitHub" class="team"></a>
		</li>
		<li>
			<a href = "https://github.com/adpextwindong"><img src="imgs/yuya.jpg" alt="George's GitHub" class="team"></a>
		</li>
		<li>
			<a href = "https://github.com/leian7"><img src="imgs/leian.jpg" alt="Anne's GitHub" class="team"></a>
		</li>
		<li>
			<a href = "https://github.com/farnhamr"><img src="imgs/farnhamr.png" alt="Rebecca's GitHub" class= "team"></a>
		</li>
		<div>
		<p> ©2016 OSU Rides</p>
		</div>
</footer>
</body></html>
<?php
?>
